
package paroimpar;

import java.util.Scanner;

public class ParOimpar {

  
    public static void main(String[] args) {
       Scanner entrada = new Scanner(System.in);
       
       int numero;
        System.out.print("Ingrese un numero");
numero = entrada.nextInt();
if (numero%2!=0)
    System.out.println("El numero es impar");
        else 
    System.out.println("El numero es par");
    }
    
}
