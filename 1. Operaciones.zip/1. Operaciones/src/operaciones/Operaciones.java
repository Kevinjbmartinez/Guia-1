
package operaciones;

import java.util.Scanner;

public class Operaciones {

    public static void main(String[] args) {
    Scanner entrada = new Scanner (System.in);
    
    double numero1, numero2, sum, rest, mult, div;
    int base, exponente;
    
    
        System.out.print("Ingrese primer numero");
        numero1 = entrada.nextDouble();
        
        System.out.print("Ingrese segundo numero");
        numero2 = entrada.nextDouble();
        
        sum = numero1 + numero2;
        rest = numero1 - numero2;
        mult = numero1 * numero2;
        div = numero1 / numero2;
        
        
        System.out.println("El resultado de la suma es: "+sum);
        System.out.println("El resultado de la resta es: "+rest);
        System.out.println("El resultado de la Multiplicacion es: "+mult);
        System.out.println("El resultado de la division es: "+div);
        
        
        
    }
    
}
