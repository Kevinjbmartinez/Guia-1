
package area;

import java.util.Scanner;


public class Area {

    public static void main(String[] args) {
    Scanner entrada = new Scanner (System.in);
    double altura, base, lado = 0, rectangulo, cubo = 0, cuadrado;
    
        System.out.print("Ingrese el valor de la base");
        base = entrada.nextDouble();
        System.out.print("Ingrese el valor de la altura");
        altura = entrada.nextDouble();
        System.out.print("Ingrese el valor del lado");
        lado = entrada.nextDouble();
        
        rectangulo = (base * altura)/2;
        cuadrado = base * altura;
        cubo = lado*lado*6;
        System.out.println("El area del rectangulo es igual a: "+rectangulo);
        System.out.println("El area de un cubo es igual a: "+ cubo); 
        System.out.println("El area de un cuadrado es igual a: "+cuadrado);
        
       
       
        
         
        }
        
    
    
    
    }
    
}
