package estadoderesultado;

import java.util.Scanner;

public class EstadoDeResultado {

    public static void main(String[] args) {
Scanner entrada = new Scanner (System.in);

int vent,costven,UtilBru, GastOp,UtilOp,OtrProd,OtrGast,UtilantImpYPTU;
double ImpRent, PTU, UtilNet;
        
        System.out.println("Ingrese el valor de las ventas");
        vent = entrada.nextInt();
        System.out.println("Ingrese el valor de los costos de ventas");
           costven = entrada.nextInt();
        UtilBru = vent - costven;
        System.out.println("Ingrese el valor de los gastos de operacion");
        GastOp = entrada.nextInt();
        UtilOp = UtilBru - GastOp;
        System.out.println("Ingrese el valor de otros productos");
        OtrProd = entrada.nextInt();
        System.out.println("Ingrese el valor de otros gastos");
        OtrGast = entrada.nextInt();
        UtilantImpYPTU = UtilOp - OtrGast - OtrProd;
        ImpRent = UtilantImpYPTU * .28;
        System.out.println("Ingrese el valor de la participacion de los empleados");
        PTU = entrada.nextInt();
        UtilNet = UtilantImpYPTU - ImpRent - PTU;
        
        System.out.println("K.M. COMERCIALIZADORA S.A");
        System.out.println("Estado de resultados del 1 de Enero al 31 de Diciembre del 2019");
        System.out.println("Ventas                                                      "+vent);
        System.out.println("Costo de ventas                                             "+costven);
        System.out.println("Utilidad bruta                                              "+UtilBru);
        System.out.println("Gastos de operacion                                         "+GastOp);
        System.out.println("Utilidad en operacion                                       "+UtilOp);
        System.out.println("Otros productos                                             "+OtrProd);
        System.out.println("Otros gastos                                                "+OtrGast);
        System.out.println("Utilidad antes de ISR y PTU                                 "+UtilantImpYPTU);
        System.out.println("Inpuesto sobre la renta (ISR) 28 %                          "+ImpRent);        
        System.out.println("Participacion de los trabajadores en las utilidades(PTU)    "+PTU);
        System.out.println("Utilidad neta                                               "+UtilNet);
             
        

    }
    
}
