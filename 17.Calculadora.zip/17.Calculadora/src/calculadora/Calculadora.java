
package calculadora;
import java.util.*;

public class Calculadora {

    
    public static void main(String[] args) {
    Scanner obj = new Scanner(System.in);
    
        Formulas formobj= new Formulas();// esto es instansiar un objeto
        
        System.out.println("Ingrese el 1er valor");
        double num1 = obj.nextDouble();
        System.out.println("Ingrese el 2do valor");
        double num2 = obj.nextDouble();
        System.out.println("La suma de 2 numeros es: "+formobj.sumar(num1,num2));
        System.out.println("La resta de 2 numeros es: "+formobj.restar(num1,num2));
        System.out.println("La multiplicacion de 2 numeros es: "+formobj.multiplicar(num1,num2));
        System.out.println("La division de 2 numeros es: "+formobj.dividir(num1,num2));
        System.out.println("La potencia de "+num1+" a la "+num2+" es "+formobj.potencia(num1, num2));
    }
    
}
