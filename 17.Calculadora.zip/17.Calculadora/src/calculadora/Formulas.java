/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

/**
 *
 * @author USUARIO constructor es un metodo que no devuelve ningun valor
 * cuando tenemos un constructor con parametros se le llama sobrecarga
 */
public class Formulas {
    private double num1=0,num2=0,num3=0;
    
 
    public Formulas() {
        this.num1=0;
        this.num2=0;
        this.num3=0;
       }
    public Formulas (double num1, double num2, double num3){   // los parametros se declaran con el tipo de dato
    
        this.num1=0;
        this.num2=0;
        this.num3=0;
    
    }
    public double sumar(double num1, double num2){
        return num1 + num2;
    }
    public double restar(double num1, double num2){
        return num1 - num2;
    }
    public double multiplicar (double num1, double num2){
        return num1 * num2;
    }
    
    public double potencia (double num1, double num2){
      return  Math.pow(num1, num2);
              }
    public double dividir (double num1, double num2){
        double dividir = 0;
        if (num2 !=0){
            
        }
        return num1 / num2;
    }

    } 

    