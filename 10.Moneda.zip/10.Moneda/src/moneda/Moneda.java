
package moneda;

import java.util.Scanner;


public class Moneda {

   
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
    double lps;
    double dolar;
    double pdolar= 24.825;
    double euro;
    double peuro=27.54;
    double quetzal;
    double pquetzal=3.24;
    double bitcoin;
    double pbitcoin= 232970.94;
    int resp = 0;
    
         while (resp != -1){      
        System.out.println("         Bienvenido           ");
        System.out.println("Seleccione el tipo de moneda que desea convertir");
        System.out.println("1. Dolar ");
        System.out.println("2. Euro  ");
        System.out.println("3. Quetzal ");
        System.out.println("4. Bitcoin ");
        System.out.println("-1. Salir ");
        System.out.println(" Que desea realizar... ? ");
        resp = entrada.nextInt();
        
        
        switch (resp){
            case 1 :
                System.out.println("El valor del dolar es L. 24.835 ");
                System.out.println("Ingrese la cantidad de dolares a convertir");
                dolar= entrada.nextDouble();
                lps= dolar * pdolar ;
                System.out.println("El valor en Lempiras es igual a: "+ lps);
               break;
                
            case 2:
                System.out.println("El valor del euro es L. 27.54 ");
                System.out.println("Ingrese la cantidad de euros a convertir");
                euro= entrada.nextDouble();
                lps= euro * peuro ;   
                System.out.println("El valor en Lempiras es igual a: "+ lps);
                break;
                
            case 3:
                System.out.println("El valor del quetzal es L. 3.24 ");
                System.out.println("Ingrese la cantidad de quetzales a convertir");
                quetzal= entrada.nextDouble();
                lps= quetzal * pquetzal ;
                System.out.println("El valor en Lempiras es igual a: "+ lps);
                break;
                
            case 4:
                System.out.println("El valor del bitcoin es L. 232,970.94 ");
                System.out.println("Ingrese la cantidad de bitcoin a convertir");
                bitcoin= entrada.nextDouble();
                lps= bitcoin * pbitcoin ;
                System.out.println("El valor en Lempiras es igual a: "+ lps);
                break;
                default :
                    resp = 0;
        }
    
        System.out.println("Presione -1 para salir, 0 para volver al menu");
            resp = entrada.nextInt();
    
        }
        
    }
}
       

