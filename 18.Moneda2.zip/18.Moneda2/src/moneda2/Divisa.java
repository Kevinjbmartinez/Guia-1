
package moneda2;


public class Divisa {
    
    private double num1=0,num2=0;
    
    public Divisa () {
        this.num1=0;
        this.num2=0;
        
       }
    public double dolar (double num1, double  num2){
    return num1*num2;
    }
    public double euro (double num1, double  num2){
    return num1*num2;
    }
    
    public double quetzal (double num1, double  num2){
    return num1*num2;
    }
}
