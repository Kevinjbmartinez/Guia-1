
package moneda2;

import java.util.*;
public class Moneda2 {

    public static void main(String[] args) {
Scanner entrada = new Scanner(System.in);
Divisa divobj = new Divisa ();
        
    double lps;
    double dolar;
    double euro;
    double quetzal;
    double num1;
    double num2;
    int resp = 0;
    
         while (resp != -1){      
        System.out.println("         Bienvenido           ");
        System.out.println("Seleccione el tipo de moneda que desea convertir");
        System.out.println("1. Dolar ");
        System.out.println("2. Euro  ");
        System.out.println("3. Quetzal ");
        System.out.println("-1. Salir ");
        System.out.println(" Que desea realizar... ? ");
        resp = entrada.nextInt();
        
        
        switch (resp){
            case 1 :
                System.out.println("Divisa");
                num1=entrada.nextDouble();
                System.out.println("Nombre: Dolar ");
                System.out.println("Tasa de cambio: ");
                num2=entrada.nextDouble();
                System.out.println("Pais: Estados Unidos");
                System.out.println("Simbolo: $");
                System.out.println("Monto en lempiras");
               System.out.println("Convesion "+divobj.dolar(num1, num2)+"Lps");
               break;
                
            case 2:
                System.out.println("Divisa");
                num1=entrada.nextDouble();
                System.out.println("Nombre: Euro ");
                System.out.println("Tasa de cambio: ");
                num2=entrada.nextDouble();
                System.out.println("Pais: Continente Europeo");
                System.out.println("Simbolo: € ");
                System.out.println("Monto en lempiras");
                System.out.println("Convesion "+divobj.euro(num1, num2)+"Lps");
                break;
                
            case 3:
                System.out.println("Divisa");
                num1=entrada.nextDouble();
                System.out.println("Nombre: Quetzal ");
                System.out.println("Tasa de cambio: ");
                num2=entrada.nextDouble();
                System.out.println("Pais: Guatemala");
                System.out.println("Simbolo: Q");
                System.out.println("Monto en lempiras");
                System.out.println("Convesion "+divobj.quetzal(num1, num2)+"Lps");
                break;
                default :
                    resp = 0;
        }
    
        System.out.println("Presione -1 para salir, 0 para volver al menu");
            resp = entrada.nextInt();
    
        }
        
    }
    
}
