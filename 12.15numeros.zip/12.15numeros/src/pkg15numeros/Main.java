
package pkg15numeros;




public class Main {

    public static void main(String[] args) {
    for (int i=1; i<16; i++)
            System.out.println("Los primeros numeros reales son "+i);
        
        
    }
    
}
