
package promedio;

import java.util.Scanner;


public class Promedio {

    
    public static void main(String[] args) {
    Scanner entrada = new Scanner(System.in);
    int numero1,numero2,numero3,numero4,numero5,promedio,suma;
    
        System.out.println("Ingrese primer numero");
        numero1 = entrada.nextInt();
        System.out.println("Ingrese segundo numero");
        numero2 = entrada.nextInt();
        System.out.println("Ingrese tercer numero");
        numero3 = entrada.nextInt();
        System.out.println("Ingrese cuarto numero");
        numero4 = entrada.nextInt();
        System.out.println("Ingrese quinto numero");
        numero5 = entrada.nextInt();
        
        promedio = (numero1+numero2+numero3+numero4+numero5)/5;
        suma = numero1+numero2+numero3+numero4+numero5;
          
        System.out.println("La suma de los numeros ingresados es: "+suma);
        System.out.println("El promedio de los numeros ingresados es: "+promedio);
        
        
            }
    
}
