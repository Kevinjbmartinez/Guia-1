
package conversormasa;
import java.util.*;
        
public class ConversorMasa {

    public static void main(String[] args) {
       
        Scanner entrada = new Scanner(System.in);
        
        double kilog;
        double gram;
        double libra;
        double tonelada;
        int resp=0;
        
        System.out.println("");
        while (resp != -1){      
        System.out.println("         Bienvenido           ");
        System.out.println("Seleccione el peso que desea convertir");
        System.out.println("1. Kilogramo ");
        System.out.println("2. Gramo  ");
        System.out.println("3. Tonelada ");
        System.out.println("-1. Salir ");
        System.out.println(" Que desea realizar... ? ");
        resp = entrada.nextInt();
    
        switch (resp){
            case 1 :
                System.out.println("1 Kilogramo es igual a 2.20 Lb ");
                System.out.println("Ingrese la cantidad a convertir");
                kilog= entrada.nextDouble();
                libra= kilog * 2.20 ;
                System.out.println("El peso es igual a: "+ libra);
               break;
            
            case 2:
                System.out.println("1 gramo es igual 0.00220462 Lb ");
                System.out.println("Ingrese la cantidad a convertir");
                gram= entrada.nextDouble();
                libra= gram * 0.00220462 ;   
                System.out.println("El peso es igual a: "+ libra);
                break;
                
            case 3:
                System.out.println("1 Tonelada es igua a 2204.62 Lb ");
                System.out.println("Ingrese la cantidad a convertir");
                tonelada= entrada.nextDouble();
                libra= tonelada * 2204.62 ;
                System.out.println("El peso es igual a: "+ libra);
                break;                
                default :
                    resp = 0;
        }
    
        System.out.println("Presione -1 para salir, 0 para volver al menu");
            resp = entrada.nextInt();
    }
    }
}
    
