
package hipotenusa;

import java.util.Scanner;

public class Hipotenusa {

    
    public static void main(String[] args) {
    Scanner entrada = new Scanner (System.in);
    int a,b,h;
    
        System.out.print("Ingrese el valor de a");
        a = entrada.nextInt();
        System.out.print("Ingrese el valor de b");
        b = entrada.nextInt();
        
        h = (a*a) + (b*b);
        System.out.println("El valor de la hipotenusa es: "+h);
        
        
               
    }
    
}
