
package ahorro2;
import java.util.*;
/**
 *
 * @author USUARIO
 */
public class Ahorro2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int meses=0;
        double cuotamen=0;
        
        System.out.println("Ingrese la cantidad que va a ahorrar");
        cuotamen=entrada.nextDouble();
        System.out.println("Ingrese el valor de la cuota mensual");
        meses=entrada.nextInt();
        
        for (int i=1; i<meses; i++)
            System.out.println("Mes "+i+" "+(i*cuotamen));
        
    }
    
}
