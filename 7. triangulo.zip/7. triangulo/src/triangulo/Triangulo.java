
package triangulo;

import java.util.Scanner;


public class Triangulo {

    
    public static void main(String[] args) {
     Scanner entrada = new Scanner (System.in);
     
     int lado1, lado2,lado3, tipo;
        System.out.println("Ingrese las medidas");
        System.out.println("Ingrese valor lado 1");
        lado1 = entrada.nextInt();
        System.out.println("Ingrese valor lado 2");
        lado2 = entrada.nextInt();
        System.out.println("Ingrese valor lado 3");
        lado3 = entrada.nextInt();
        
        
        if ((lado1 == lado2)&&(lado2 == lado3 )){
        System.out.println("El triangulo es equilatero");
    }
        if ((lado1 == lado2)&&(lado2 != lado3)||(lado2 == lado3)&&(lado3 != lado1) || (lado1==lado3)&& (lado3 != lado2)){
        System.out.println("El triangulo es Isosceles");
    }
      if ((lado1 != lado2)&& (lado1  != lado3)&& (lado2 != lado3) && (lado2 != lado1) && (lado3 != lado2)&& (lado3 != lado1))
      {
        System.out.println("El triangulo es Escaleno");
}
    }
    
}
