
package planilla;

import java.util.Scanner;


public class Planilla {

  
    public static void main(String[] args) {
       Scanner entrada = new Scanner(System.in);
       int horasdetrab =40;
       int pagoxhora = 100;
       int horaextr = 150;
       int horastrab = 0;
       int salario = 0;
       
        System.out.println("Ingrese el numero de horas trabajadas en la semana");
        horastrab = entrada.nextInt();
        
        if (horastrab <= horasdetrab){
            salario = horastrab*pagoxhora;
        }
        else 
        {
            salario = (horastrab-horasdetrab)*horaextr+horasdetrab*pagoxhora;
        }
        System.out.println("El salario de la semana es:  "+salario);
       
    }
    
}
